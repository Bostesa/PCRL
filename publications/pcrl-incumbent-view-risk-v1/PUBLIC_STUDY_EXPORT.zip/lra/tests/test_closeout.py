"""[lra port of lcr/tests/test_closeout.py at 091afc2: lcr->lra renames; later edits are listed in PORT_LOG.md]
Tests for lra.closeout (role F, custody). SYNTHETIC ONLY: everything runs in pytest's tmp_path with fake volumes
(drive detection by content, skipped names), a fake private store and pinned input, stubbed restores, a fake cbp closeout
module for the redirected cbp custody, and a synthetic teacher + qpc token map + lra.decoder D1 table for an end-to-end
restore from a copy. No private store, drive, closed results tree or git ref is written; no Adult data is loaded.
Adapted from cbp/tests/test_closeout.py (the synthetic teacher-store helpers are imported from qpc's tests unchanged).

    OMP_NUM_THREADS=1 PYTHONPATH=. ~/PCRL/.venv/bin/python -m lra.sema --label F:closeout-tests -- env \\
        OMP_NUM_THREADS=1 PYTHONPATH=. ~/PCRL/.venv/bin/python -m pytest -q lra/tests/test_closeout.py
"""
from __future__ import annotations

import hashlib
import json
import shutil
import time
import types
from pathlib import Path

import numpy as np
import pytest

from cbp import closeout as CBC
from lra import closeout as CO
from qpc import closeout as QC
from qpc.tests.test_closeout import _complete, _synthetic_store

SUMS = b"deadbeef  smf_v1/run/units/x/COMPLETE.json\n"
WANT = hashlib.sha256(SUMS).hexdigest()
DATE = time.strftime("%Y%m%d", time.gmtime())
SMF = "private_smf_v1_20261005"
REAL_MARKER = CO.smf_marker_sha
INPUT_BYTES = b"pinned-input-standin"


def _volumes(tmp: Path, match=True):
    root = tmp / "Volumes"
    for n in ("Macintosh HD", "BackgroundSyncService Setup", "Unrelated Stick", "Owner Named Disk"):
        (root / n).mkdir(parents=True)
    for skipped in ("Macintosh HD", "BackgroundSyncService Setup"):      # a match on a SKIPPED volume never counts
        (root / skipped / SMF).mkdir()
        (root / skipped / SMF / "SHA256SUMS").write_bytes(SUMS)
    (root / "Unrelated Stick" / SMF).mkdir()
    (root / "Unrelated Stick" / SMF / "SHA256SUMS").write_bytes(b"other")
    if match:
        d = root / "Owner Named Disk" / SMF
        d.mkdir()
        (d / "SHA256SUMS").write_bytes(SUMS)
        (root / "Owner Named Disk" / "Owner Personal Folder").mkdir()     # an identifying name: never published
    return root


@pytest.fixture(autouse=True)
def _isolate(tmp_path, monkeypatch):
    """Marker, lock states, closed trees, receipt folders and the pinned input all point into tmp_path."""
    monkeypatch.setattr(CO, "smf_marker_sha", lambda: WANT)
    monkeypatch.setattr(CO, "lra_lock_pushed", lambda: (False, "not pushed (test)"))
    monkeypatch.setattr(CO, "_engineering_ready", lambda: (False, "no gate result (test)"))
    monkeypatch.setattr(CBC, "cbp_lock_pushed", lambda: (True, "pushed (test)"))
    closed = {k: tmp_path / "closed" / k for k in ("cbp_results", "qpc_results", "dpc_results", "osf_results",
                                                   "smf_results")}
    for d in closed.values():
        d.mkdir(parents=True)
        (d / "R.json").write_text("{}")
    monkeypatch.setattr(CO, "CLOSED_RESULTS", closed)
    monkeypatch.setattr(CO, "PKG", tmp_path / "pkg")
    monkeypatch.setattr(CO, "CBP_CUSTODY_DIR", tmp_path / "pkg" / "provenance" / "cbp_custody")
    monkeypatch.setattr(CO, "diskutil_probe", lambda: {"ran": False})
    inp = tmp_path / "jcv" / "adult_jcv.npz"
    inp.parent.mkdir(parents=True)
    inp.write_bytes(INPUT_BYTES)
    monkeypatch.setattr(CO, "INPUT", inp)
    monkeypatch.setattr(CO, "INPUT_SHA", hashlib.sha256(INPUT_BYTES).hexdigest())
    monkeypatch.setattr(CO, "LRA_TARGETS", tmp_path / "no_targets.json")
    monkeypatch.setattr(CO, "SRC", tmp_path / "no_live_store")
    monkeypatch.setattr(CO, "CBP_TARGETS", tmp_path / "no_cbp_targets.json")
    return closed


def _store(tmp: Path):
    src = tmp / "PCRL_eval_cache_private" / "lra_v1"
    (src / "run" / "units" / "u").mkdir(parents=True)
    (src / "run" / "units" / "u" / "f.bin").write_bytes(b"x" * 100)
    (src / "run" / "units" / "u" / "f.bin.tmp").write_bytes(b"partial")          # in-progress write: excluded
    (src / "START.txt").write_text("t0\n")
    return src


def _stub_restore(monkeypatch, status="PASS", dec="PASS"):
    def fake(copy, live, targets, seed, input_path):
        return ({"teacher U (seed 1)": {"status": status, "copy_seen": (Path(copy) / "START.txt").exists(),
                                        "copy_is_not_live": Path(copy) != Path(live),
                                        "input_in_copy": Path(input_path).exists() and Path(copy).parent in
                                        Path(input_path).parents},
                 "Q (D0 DIRECT-TASK i8o64)": {"status": "PASS"},
                 "P* (LOCAL; calibrated U|LOCAL|i8o64|l0.06|D1)": {"status": dec,
                                                                    "decoder_recertified_from_copy": {"status": dec}},
                 "attacker": {"status": "PASS"}}, {"wall_s": 0.0, "cpu_s": 0.0})
    monkeypatch.setattr(CO, "restore_all", fake)


# ------------------------------------------------------------------ drive detection, pins, code identity
def test_locate_drive_by_content_skips_names_and_withholds_them(tmp_path):
    root = _volumes(tmp_path)
    vol, ev = CO.locate_drive(root)
    assert vol == root / "Owner Named Disk"
    assert ev["skipped_by_name"] == 2 and ev["candidate_volumes"] == 2 and ev["matching_volumes"] == 1
    txt = json.dumps(ev)
    assert "Owner" not in txt and "Unrelated" not in txt and "Background" not in txt and "Macintosh" not in txt


def test_skipped_installer_image_is_never_read(tmp_path, monkeypatch):
    root = _volumes(tmp_path, match=False)
    seen = []
    orig = CO.DC.sha
    monkeypatch.setattr(CO.DC, "sha", lambda p, nocache=False: (seen.append(str(p)), orig(p, nocache))[1])
    vol, ev = CO.locate_drive(root)
    assert vol is None and ev["mounted"] is False
    assert not [s for s in seen if "BackgroundSyncService" in s or "Macintosh" in s]
    assert "BackgroundSyncService Setup" in CO.SKIP_VOLUMES


def test_status_reports_the_gate_the_opening_and_the_science_state_without_writing(tmp_path):
    before = sorted(p.name for p in tmp_path.iterdir())
    st = CO.status(volumes_root=_volumes(tmp_path / "v", match=False))
    assert st["mounted"] is False and st["lra_state"]["assessment_opened_by_this_study"] is False
    assert st["lra_state"]["study_label"] is None and st["science"]["science_ran"] is False
    assert "Background" not in json.dumps(st) and sorted(p.name for p in tmp_path.iterdir()) == sorted(before + ["v"])


def test_marker_is_read_at_the_pin():
    assert REAL_MARKER() == "28705e242f77b6333561f66117934b3ebc427072e31dc5a38b3a9d9e8f02cd05"


def test_pinned_packages_are_byte_identical_to_the_cbp_tip():
    ident = CO.source_code_identity()
    assert ident["identical"] and ident["files"] > 40 and not ident["differing_from_cbp_tip"]
    assert ident["pin"] == CO.CBP_TIP


# ------------------------------------------------------------------ same-device and drive copies
def test_same_device_copy_bundles_the_input_is_labelled_pending_and_restored_from_the_copy(tmp_path, monkeypatch):
    src = _store(tmp_path)
    out = tmp_path / "pkg"
    _stub_restore(monkeypatch)
    bv = CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=out)
    assert bv["status"] == CO.STATUS_LOCAL == "LOCAL_SAME_DEVICE_COPY_VERIFIED_OFF_DEVICE_BACKUP_PENDING"
    assert "not a drive restore" in bv["restore_kind"] and bv["off_device_backup"].startswith("PENDING")
    assert "not off-device custody" in bv["custody_gap"]
    assert bv["pending"] == CO.PENDING and "<DRIVE_ROOT>" in CO.PENDING["lra_off_device_backup_and_restore"]
    assert all(v.startswith(CO.SEMA) for k, v in CO.PENDING.items() if not k.endswith("_for_its_owner"))
    assert CO.PENDING["lcr_off_device_backup_for_its_owner"].startswith("cd <LCR_WORKTREE> && ")
    own = CO.PENDING["cbp_qpc_dpc_osf_smf_pending_custody_for_its_owner"]
    assert own.startswith("cd <CBP_WORKTREE> && ") and "-m cbp.sema" in own and \
        "cbp.closeout all --targets <PRIVATE_CACHE>/cbp_v1/run/closeout_targets.json" in own and "OPENS osf" in own
    assert bv["files"] == 3 and bv["store_files"] == 2 and bv["dependency_files"] == 1 and bv["uncached_readback_match"] == 3
    root = src.parent / f"lra_v1_local_copy_{DATE}"
    assert (root / "lra_v1" / "START.txt").exists() and not (root / "lra_v1/run/units/u/f.bin.tmp").exists()
    assert (root / CO.DEP_REL).read_bytes() == INPUT_BYTES
    lines = (root / "SHA256SUMS").read_text().splitlines()
    assert len(lines) == 3 and {ln.split("  ")[1].split("/")[0] for ln in lines} == {"lra_v1", "dependencies"}
    assert CO.verify_sums(root)["pass"]
    pub = (out / "BACKUP_VERIFICATION.json").read_text() + (out / "RESTORE_INDEX.json").read_text()
    assert "/Users/" not in pub and str(tmp_path) not in pub and "<PRIVATE_CACHE>" in pub
    assert CO.STATUS_DRIVE not in pub and json.loads((out / "RESTORE_INDEX.json").read_text())["not_off_device"]
    chk = bv["restore_checks"]["teacher U (seed 1)"]
    assert chk["copy_seen"] and chk["copy_is_not_live"] and chk["input_in_copy"]
    assert bv["required_restores"] == {"U teacher": "PASS", "learned decoder": "PASS", "protected map": "PASS",
                                       "Q": "PASS", "constrained candidate": "PENDING (no constrained candidate target)",
                                       "decoder-only baseline": "PENDING (no decoder-only baseline target)",
                                       "sequential winner": "PENDING (no sequential winner target)", "attacker": "PASS"}
    assert bv["restore_all_pass"] is True and bv["science"]["science_ran"] is False
    assert bv["read_capability"]["F_NOCACHE_uncached_read"] == "available"
    assert "not performed" in bv["read_capability"]["physical_cold_read"]
    assert (root / "BACKUP_RECORD.json").exists()
    bv2 = CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path / "b", match=False), out_pkg=out)
    assert bv2["destination"].endswith(f"lra_v1_local_copy_{DATE}_v2/lra_v1")
    assert (root / "lra_v1" / "START.txt").exists()                                # the first copy is kept


def test_public_receipts_are_finite_or_null(tmp_path, monkeypatch):
    src = _store(tmp_path)
    out = tmp_path / "pkg"

    def fake(copy, live, targets, seed, input_path):
        return ({"teacher U (seed 1)": {"status": "PASS"},
                 "attacker": {"status": "FAIL", "max_abs_diff_vs_saved_copy": float("inf")}}, {"wall_s": float("nan")})
    monkeypatch.setattr(CO, "restore_all", fake)
    bv = CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=out)
    txt = (out / "BACKUP_VERIFICATION.json").read_text()
    assert "Infinity" not in txt and "NaN" not in txt
    z = json.loads(txt)
    assert z["restore_checks"]["attacker"]["max_abs_diff_vs_saved_copy"] is None and bv["restore_all_pass"] is False


def test_drive_copy_goes_to_the_content_matched_volume_only(tmp_path, monkeypatch):
    src = _store(tmp_path)
    vols = _volumes(tmp_path)
    _stub_restore(monkeypatch)
    bv = CO.backup(src=src, cache=src.parent, volumes_root=vols, out_pkg=tmp_path / "pkg")
    assert bv["status"] == CO.STATUS_DRIVE and bv["destination"] == f"<DRIVE_ROOT>/private_lra_v1_{DATE}/lra_v1"
    assert "custody_gap" not in bv and "Owner" not in json.dumps(bv)
    assert (vols / "Owner Named Disk" / f"private_lra_v1_{DATE}" / "lra_v1" / "START.txt").exists()
    assert (vols / "Owner Named Disk" / f"private_lra_v1_{DATE}" / CO.DEP_REL).exists()
    assert not (vols / "Unrelated Stick" / f"private_lra_v1_{DATE}").exists()
    assert not (vols / "BackgroundSyncService Setup" / f"private_lra_v1_{DATE}").exists()


def test_backup_refuses_when_free_space_would_drop_below_5_gib(tmp_path, monkeypatch):
    src = _store(tmp_path)
    monkeypatch.setattr(CO, "free_gib", lambda p: 5.0)
    _stub_restore(monkeypatch)
    with pytest.raises(SystemExit, match="5 GiB"):
        CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=tmp_path / "pkg")
    assert not list(src.parent.glob("lra_v1_local_copy_*"))


def test_backup_refuses_a_dependency_that_fails_its_pin(tmp_path, monkeypatch):
    src = _store(tmp_path)
    _stub_restore(monkeypatch)
    CO.INPUT.write_bytes(b"tampered")
    with pytest.raises(SystemExit, match="pinned hash"):
        CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=tmp_path / "pkg")
    assert not list(src.parent.glob("lra_v1_local_copy_*"))


def test_failed_restore_is_not_reported_as_passing(tmp_path, monkeypatch):
    src = _store(tmp_path)
    _stub_restore(monkeypatch, status="FAIL")
    bv = CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=tmp_path / "pkg")
    assert bv["restore_all_pass"] is False and bv["required_restores"]["U teacher"] == "FAIL"
    _stub_restore(monkeypatch, dec="FAIL")
    bv = CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path / "b", match=False), out_pkg=tmp_path / "pkg")
    assert bv["restore_all_pass"] is False and bv["required_restores"]["learned decoder"] == "FAIL"


def _roles(over=None, drop=()):
    """A truthful, structurally valid role-target set for seed 1 (synthetic unit names; nothing is restored)."""
    r = {"Q": {"status": "NOMINATED", "unit": "pol__s1__U_DIRECT-TASK_i8o64", "config": "U|DIRECT-TASK|i8o64"},
         "P*": {"status": "NOMINATED", "unit": "dec__s1__U_LOCAL_i8o64_l0.06_D1", "config": "U|LOCAL|i8o64|l0.06|D1",
                "family": "LOCAL", "construction": "calibrated"},
         "constrained candidate": {"status": "DESCRIPTIVE_FALLBACK", "unit": "new__s1__U_K-JOINT-PAIR_i8o64_D1",
                                   "config": "U|K-JOINT-PAIR|i8o64|D1", "selection_role": "N*",
                                   "reason": "CONSTRAINED_FIT_INFEASIBLE"},
         "decoder-only baseline": {"status": "FIXED", "unit": "pol__s1__U_LOCAL_i8o64_l0.06",
                                   "config": "U|LOCAL|i8o64|l0.06", "paired_with": "P*"},
         "sequential winner": {"status": "FIXED", "unit": "new__s1__U_K-SEQ-12_i8o64_D1",
                               "config": "U|K-SEQ-12|i8o64|D1"}}
    for k, v in (over or {}).items():
        r[k] = v
    for k in drop:
        r.pop(k)
    return r


def _write(t, obj):
    t.write_text(json.dumps(obj))
    return t


def test_not_applicable_classes_are_reported_not_failed(tmp_path, monkeypatch):
    """Before any Adult science (e.g. ENGINEERING_BLOCKED_NOT_RUN): roles without a release carry a truthful status
    (NOT_RUN / ABSENT + reason) and are NOT_APPLICABLE (never a failure, never silently PENDING); the decoder and the
    attacker may be marked not applicable only while no Adult D1 unit exists; the U teacher never can."""
    why = "ENGINEERING_BLOCKED_NOT_RUN: no Adult fit"
    roles = {"Q": {"status": "FIXED", "unit": "pol__s1__U_DIRECT-TASK_i8o64", "config": "U|DIRECT-TASK|i8o64"},
             **{r: {"status": "NOT_RUN", "reason": why} for r in CO.ROLES if r != "Q"}}
    na = {"learned decoder": "no Adult D1 decoder fitted", "attacker": "no lra attacker fitted"}
    st = {"teacher U (seed 1)": "PASS", "Q [FIXED] U|DIRECT-TASK|i8o64": "PASS", "attacker": "NOT_APPLICABLE"}
    req = CO.required_targets_status(st, {}, na, roles)
    assert req == {"U teacher": "PASS", "learned decoder": "NOT_APPLICABLE (no Adult D1 decoder fitted)",
                   "protected map": f"NOT_APPLICABLE (NOT_RUN: {why})", "Q": "PASS",
                   "constrained candidate": f"NOT_APPLICABLE (NOT_RUN: {why})",
                   "decoder-only baseline": f"NOT_APPLICABLE (NOT_RUN: {why})",
                   "sequential winner": f"NOT_APPLICABLE (NOT_RUN: {why})",
                   "attacker": "NOT_APPLICABLE (no lra attacker fitted)"}
    t = _write(tmp_path / "t.json", {"seed": 1, "roles": roles, "not_applicable": na})
    assert CO.load_targets(t)["not_applicable"] == na
    for bad in ({"seed": 1, "roles": roles, "not_applicable": {"U teacher": "x"}},
                {"seed": 1, "roles": roles, "not_applicable": {"protected map": ""}},
                {"seed": 1, "roles": _roles(), "not_applicable": {"protected map": "x"}},
                {"seed": 1, "roles": roles, "attacker": {"fn": "lra.assess:x"}, "not_applicable": {"attacker": "x"}},
                {"seed": 1, "roles": _roles(), "not_applicable": {"learned decoder": "x"}}):
        _write(t, bad)
        with pytest.raises(SystemExit):
            CO.load_targets(t)
    # a full backup with these targets passes; the attacker restore is not attempted
    src = _store(tmp_path)
    seen = {}

    def fake(copy, live, targets, seed, input_path):
        seen["na"] = targets.get("not_applicable")
        return ({"teacher U (seed 1)": {"status": "PASS"}, "Q [FIXED] U|DIRECT-TASK|i8o64": {"status": "PASS"},
                 "attacker": {"status": "NOT_APPLICABLE", "reason": na["attacker"]}}, {"wall_s": 0.0, "cpu_s": 0.0})
    monkeypatch.setattr(CO, "restore_all", fake)
    _write(t, {"seed": 1, "roles": roles, "not_applicable": na})
    bv = CO.backup(targets_file=t, src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False),
                   out_pkg=tmp_path / "pkg")
    assert bv["restore_all_pass"] is True and seen["na"] == na
    assert bv["required_restores"]["protected map"].startswith("NOT_APPLICABLE (NOT_RUN")
    assert bv["role_statuses"]["P*"] == {"status": "NOT_RUN", "reason": why}
    ri = json.loads((tmp_path / "pkg" / "RESTORE_INDEX.json").read_text())
    assert ri["required_restores"] == bv["required_restores"] and ri["unit_inventory"] == {"u": 1}
    # once the store holds an Adult D1 unit, the decoder and the attacker can no longer be marked not applicable
    d = src / "run" / "units" / "dec__s1__U_LOCAL_i8o64_l0.06_D1"
    d.mkdir(parents=True)
    _complete(d)
    assert CO.science_state(src)["science_ran"]
    with pytest.raises(SystemExit, match="cannot be marked not applicable"):
        CO.backup(targets_file=t, src=src, cache=src.parent, volumes_root=_volumes(tmp_path / "b", match=False),
                  out_pkg=tmp_path / "pkg")


def test_required_restore_classes():
    st = {"teacher U (seed 1)": "PASS", "Q (DIRECT-TASK i8o64)": "PASS", "fallback (INELIGIBLE) U|K-JOINT-PAIR": "FAIL",
          "attacker": "PENDING"}
    checks = {"fallback (INELIGIBLE) U|K-JOINT-PAIR": {"decoder_recertified_from_copy": {"status": "PASS"}}}
    req = CO.required_targets_status(st, checks)
    assert {k: req[k] for k in ("U teacher", "learned decoder", "protected map", "Q", "attacker")} == \
        {"U teacher": "PASS", "learned decoder": "PASS", "protected map": "FAIL", "Q": "PASS", "attacker": "PENDING"}
    assert set(req) == set(CO.RESTORE_CLASSES)
    empty = CO.required_targets_status({})
    assert empty["Q"].startswith("PENDING") and empty["protected map"].startswith("PENDING")
    assert empty["learned decoder"].startswith("PENDING") and empty["U teacher"] == "FAIL"
    # after the science ran: no D1 target and no attacker restore are FAILURES, never PENDING
    sci = CO.required_targets_status({"teacher U (seed 1)": "PASS", "attacker": "PENDING"}, {}, science_ran=True)
    assert sci["learned decoder"].startswith("FAIL") and sci["attacker"].startswith("FAIL")
    ok = {k: "PASS" for k in CO.RESTORE_CLASSES}
    assert CO.restore_passed({"teacher U (seed 1)": "PASS", "attacker": "PASS"}, ok, science_ran=True)
    assert not CO.restore_passed({"teacher U (seed 1)": "PASS", "attacker": "PENDING"}, ok, science_ran=True)
    assert CO.restore_passed({"teacher U (seed 1)": "PASS", "attacker": "PENDING"}, ok, science_ran=False)
    assert not CO.restore_passed({"teacher U (seed 1)": "PASS", "attacker": "PASS"}, ok, truthful=False)
    pend = {**ok, "sequential winner": "PENDING (no sequential winner target)"}
    assert not CO.restore_passed({"teacher U (seed 1)": "PASS", "attacker": "PASS"}, pend, science_ran=True)
    # a failed same-map token check fails the decoder-only baseline even when its own restore passed
    st2 = {"teacher U (seed 1)": "PASS", "decoder-only baseline [FIXED] x": "PASS", CO.SAME_MAP_CHECK: "FAIL"}
    assert CO.required_targets_status(st2)["decoder-only baseline"].startswith("FAIL")


def test_role_targets_require_every_role_with_a_truthful_status(tmp_path):
    t = tmp_path / "t.json"
    good = {"seed": 1, "roles": _roles(), "deploy": "lra.deploy:release_d1",
            "attacker": {"fn": "lra.assess:refit_selected_attacker"}, "policies": {"U baseline": "tea__s1__U"}}
    tg = CO.load_targets(_write(t, good))
    labs = [lab for lab, _ in CO.role_targets(tg)]
    assert labs[:5] == [CO.role_label(r, _roles()[r]) for r in CO.ROLES] and labs[5] == "U baseline"
    assert labs[1] == "P* [NOMINATED] U|LOCAL|i8o64|l0.06|D1" and CO.paired_unit(tg)[1] == "dec__s1__U_LOCAL_i8o64_l0.06_D1"
    fb = {"status": "DESCRIPTIVE_FALLBACK", "unit": "new__s1__U_K-LOCAL_i8o64_D1", "config": "U|K-LOCAL|i8o64|D1",
          "selection_role": "N*", "reason": "LOCAL_GUARD_FAILURE"}
    bad = [_roles(drop=("sequential winner",)),                                          # a role omitted
           {**_roles(), "extra": {"status": "FIXED"}},                                   # an unregistered role
           _roles({"P*": {"status": "WON", "unit": "x", "config": "y"}}),               # unknown status
           _roles({"P*": {**_roles()["P*"], "status": "FIXED"}}),                        # status not allowed for P*
           _roles({"P*": {"status": "NOMINATED", "config": "U|LOCAL|i8o64|l0.06|D1"}}),  # nominee without a unit
           _roles({"P*": {"status": "NOT_RUN", "reason": "x", "unit": "dec__s1__U_LOCAL_i8o64_l0.06_D1"}}),
           _roles({"P*": {"status": "ABSENT"}}),                                         # no reason
           _roles({"constrained candidate": {**fb, "reason": ""}}),                      # fallback without a reason
           _roles({"Q": {"status": "NOMINATED", "unit": "dec__s1__U_DIRECT-TASK_i8o64_D1",
                         "config": "U|DIRECT-TASK|i8o64|D1"}}),                          # Q is the fixed D0 code
           _roles({"P*": {"status": "NOMINATED", "unit": "new__s1__U_C-TASK_i8o64_D1",
                          "config": "U|C-TASK|i8o64|D1"}}),                              # C-TASK is privacy-untrained
           _roles({"P*": {"status": "NOMINATED", "unit": "dec__s1__U_CLASS_i1o1_D1",
                          "config": "U|CLASS|i1o1|D1"}}),                                # CLASS|D1 is privacy-untrained
           _roles({"P*": {**_roles()["P*"], "unit": "dec__s2__U_LOCAL_i8o64_l0.06_D1"}}),  # another seed
           _roles({"P*": {**_roles()["P*"], "unit": "dec__s1__U_JOINT_i8o64_l0.1_D1"}}),   # unit/config mismatch
           _roles({"constrained candidate": {**fb, "unit": "new__s1__U_W-LOCAL_i8o64_l0.01_D1",
                                             "config": "U|W-LOCAL|i8o64|l0.01|D1"}}),     # a weighted control
           _roles({"constrained candidate": {k: v for k, v in fb.items() if k != "selection_role"}}),
           _roles({"decoder-only baseline": {**_roles()["decoder-only baseline"], "paired_with": "Q"}}),  # pairs D0
           _roles({"decoder-only baseline": {**_roles()["decoder-only baseline"], "paired_with": None}}),
           _roles({"decoder-only baseline": {"status": "FIXED", "unit": "dec__s1__U_LOCAL_i8o64_l0.06_D1",
                                             "config": "U|LOCAL|i8o64|l0.06|D1", "paired_with": "P*"}}),  # not D0
           _roles({"sequential winner": {"status": "FIXED", "unit": "new__s1__U_K-LOCAL_i8o64_D1",
                                         "config": "U|K-LOCAL|i8o64|D1"}})]               # not a SEQ release
    for roles in bad:
        _write(t, {"seed": 1, "roles": roles})
        with pytest.raises(SystemExit, match="REFUSED"):
            CO.load_targets(t)
    _write(t, {"seed": 1, "policies": {"Q": "pol__s1__U_DIRECT-TASK_i8o64"}})     # the legacy format is refused
    with pytest.raises(SystemExit, match="roles"):
        CO.load_targets(t)
    ok = _roles({"constrained candidate": fb, "sequential winner": {
        "status": "INVALID", "reason": "FIT_RECORD_TECHNICAL_FAILURE on seed 2"},
        "decoder-only baseline": {"status": "FIXED", "unit": "d0s__s1__U_K-LOCAL_i8o64_D1_D0SAME",
                                  "config": "U|K-LOCAL|i8o64|D1|D0SAME", "paired_with": "constrained candidate"}})
    assert CO.load_targets(_write(t, {"seed": 1, "roles": ok}))["roles"]["sequential winner"]["status"] == "INVALID"


def test_role_statuses_are_checked_against_the_inner_selection(tmp_path):
    roles = _roles()
    sel = {"statuses": {"Q": {"status": "NOMINEE", "config": "U|DIRECT-TASK|i8o64"},
                        "P*": {"status": "NOMINEE", "config": "U|LOCAL|i8o64|l0.06|D1"},
                        "N*": {"status": "NO_ELIGIBLE_NOMINEE", "config": None,
                               "descriptive_config": "U|K-JOINT-PAIR|i8o64|D1", "reason": "CONSTRAINED_FIT_INFEASIBLE"}}}
    assert CO.check_targets_against_selection({"roles": roles}, sel) == []
    lie = {**sel, "statuses": {**sel["statuses"], "P*": {"status": "NO_ELIGIBLE_NOMINEE", "config": None,
                                                         "descriptive_config": "U|LOCAL|i8o64|l0.06|D1"}}}
    mm = CO.check_targets_against_selection({"roles": roles}, lie)
    assert len(mm) == 1 and mm[0].startswith("P*: status NOMINATED but selection P* is NO_ELIGIBLE_NOMINEE")
    other = {**sel, "statuses": {**sel["statuses"], "P*": {"status": "NOMINEE", "config": "U|JOINT|i8o64|l0.1|D1"}}}
    assert "names 'U|JOINT|i8o64|l0.1|D1'" in CO.check_targets_against_selection({"roles": roles}, other)[0]
    gone = {"statuses": {k: v for k, v in sel["statuses"].items() if k != "N*"}}
    assert CO.check_targets_against_selection({"roles": roles}, gone) == ["constrained candidate: selection has no role N*"]
    # through the store: an untruthful status fails the restore verdict (the copy is still made and verified)
    src = tmp_path / "store"
    (src / "run").mkdir(parents=True)
    (src / "run" / "selection.json").write_text(json.dumps(lie))
    tr = CO.targets_truthfulness({"roles": roles}, src)
    assert tr["pass"] is False and tr["checked_against"] == "run/selection.json"
    assert CO.targets_truthfulness({"roles": roles}, tmp_path / "none")["pass"] is True


# ------------------------------------------------------------------ dry runs, targets, sums, live files
def test_dry_runs_write_nothing(tmp_path, monkeypatch, _isolate):
    src = _store(tmp_path)
    out = tmp_path / "pkg"
    monkeypatch.setattr(CO, "rehearse", lambda s, t, k: {"statuses": {}})
    monkeypatch.setattr(CO, "source_code_identity", lambda: {"identical": True, "files": 1, "differing_from_cbp_tip": []})
    before = sorted(p.name for p in src.parent.iterdir())
    trees = {k: CO.tree_state(v) for k, v in _isolate.items()}
    for lock in (False, True):
        monkeypatch.setattr(CO, "lra_lock_pushed", lambda lock=lock: (lock, "test"))
        for vols in (_volumes(tmp_path / f"a{lock}", match=False), _volumes(tmp_path / f"b{lock}", match=True)):
            drive_before = sorted(p.name for p in (vols / "Owner Named Disk").iterdir())
            CO.backup(src=src, cache=src.parent, volumes_root=vols, out_pkg=out, dry_run=True)
            CO.cbp_custody(dry_run=True, volumes_root=vols)
            CO.run_all(dry_run=True, volumes_root=vols, src=src, cache=src.parent, out_pkg=out)
            assert sorted(p.name for p in (vols / "Owner Named Disk").iterdir()) == drive_before
    assert sorted(p.name for p in src.parent.iterdir()) == before and not out.exists()
    assert {k: CO.tree_state(v) for k, v in _isolate.items()} == trees


def test_plan_only_dry_run_loads_no_data(tmp_path, monkeypatch):
    src = _store(tmp_path)
    monkeypatch.setattr(CO, "rehearse", lambda *a: (_ for _ in ()).throw(AssertionError("rehearsal ran")))
    plan = CO.run_all(dry_run=True, plan_only=True, volumes_root=_volumes(tmp_path, match=False), src=src,
                      cache=src.parent, out_pkg=tmp_path / "pkg")
    assert plan["restore_rehearsal_read_only_on_live_store"]["status"].startswith("SKIPPED")
    assert plan["self_contained"]["required"] == 20
    monkeypatch.setenv("OMP_NUM_THREADS", "1")
    with pytest.raises(SystemExit, match="requires --dry-run"):
        CO.main(["backup", "--plan-only"])


def test_targets_must_be_lra_unit_names_and_entry_points(tmp_path):
    t = tmp_path / "t.json"
    for bad in ({"policies": {"x": "../../etc/passwd"}}, {"policies": {"x": "ref__s1__F"}},
                {"policies": {"x": "inner__new__s1__U_K-LOCAL_i8o64_D1"}},
                {"policies": {}, "deploy": "os:system"}, {"policies": {}, "attacker": {"fn": "subprocess:run"}},
                {"policies": {}, "attacker": {"fn": "dpc.audit:x"}},
                {"roles": _roles({"P*": {**_roles()["P*"], "unit": "../dec__s1__U_LOCAL_i8o64_l0.06_D1"}})}):
        t.write_text(json.dumps({"seed": 1, "roles": _roles(), **bad}))
        with pytest.raises(SystemExit):
            CO.load_targets(t)
    good = {"seed": 1, "roles": _roles(), "policies": {"N* (K-LOCAL)": "new__s1__U_K-LOCAL_i8o64_D1",
                                                       "CLASS|D1 (T* pool)": "dec__s1__U_CLASS_i1o1_D1",
                                                       "same-map D0 of C-TASK": "d0s__s1__U_C-TASK_i8o64_D1_D0SAME",
                                                       "diagnostic": "diag__s1__U_CLASS_i1o1_D1"},
            "deploy": "lra.deploy:release_d1", "attacker": {"fn": "lra.assess:refit_selected_attacker"}}
    t.write_text(json.dumps(good))
    assert CO.load_targets(t)["policies"]["N* (K-LOCAL)"] == "new__s1__U_K-LOCAL_i8o64_D1"
    assert CO.load_targets(tmp_path / "absent.json")["policies"] == {}


def test_protected_paths_cover_targets_teacher_and_attacker_units():
    tg = {"seed": 2, "policies": {"P*": "dec__s2__U_LOCAL_i8o64_l0.06_D1"},
          "attacker": {"kwargs": {"outer_unit": "outer__s2__x", "release_unit": "dec__s2__U_LOCAL_i8o64_l0.06_D1"},
                       "saved": {"unit": "outer__s2__x"}}}
    p = CO.protected_paths(tg, 1)
    assert "lra_v1/run/units/dec__s2__U_LOCAL_i8o64_l0.06_D1/" in p and "lra_v1/admitted/rel__s2__U/" in p
    assert "lra_v1/run/units/outer__s2__x/" in p and "lra_v1/run/units/tea__s2__U/" in p and len(p) == len(set(p))


def test_verify_sums_detects_corruption(tmp_path):
    d = tmp_path / "f"
    (d / "a").mkdir(parents=True)
    (d / "a" / "x").write_bytes(b"hello")
    (d / "SHA256SUMS").write_text(f"{hashlib.sha256(b'hello').hexdigest()}  a/x\n")
    assert CO.verify_sums(d)["pass"]
    (d / "a" / "x").write_bytes(b"hellO")
    r = CO.verify_sums(d)
    assert not r["pass"] and r["entries"] == 1 and r["match"] == 0
    assert CO.verify_sums(tmp_path / "missing")["pass"] is False


def test_copy_records_a_live_file_that_keeps_changing(tmp_path, monkeypatch):
    src = _store(tmp_path)
    log = src / "run" / "SEMA_LOG.jsonl"
    log.write_text("a\n")
    real = shutil.copy2

    def appending_copy(s, d, **kw):                         # another process appends during every copy of the log
        out = real(s, d, **kw)
        if Path(s).name == "SEMA_LOG.jsonl":
            with open(s, "a") as fh:
                fh.write("x\n")
        return out
    monkeypatch.setattr(shutil, "copy2", appending_copy)
    copy, cp = CO.copy_study(src, tmp_path / "out" / "lra_v1_local_copy_x", {CO.DEP_REL: CO.INPUT})
    assert cp["live_files_changed_during_copy"] == ["lra_v1/run/SEMA_LOG.jsonl"]
    assert cp["source_stable_during_copy"] == cp["files"] - 1 and cp["uncached_readback_match"] == cp["files"]
    assert CO.verify_sums(tmp_path / "out" / "lra_v1_local_copy_x")["pass"]
    with pytest.raises(SystemExit, match="never reused"):
        CO.copy_study(src, tmp_path / "out" / "lra_v1_local_copy_x")


# ------------------------------------------------------------------ the pending cbp / qpc / dpc / osf / smf custody
def test_cbp_custody_pending_without_drive_never_calls_the_source_closeout(tmp_path, _isolate):
    called = []
    fake = types.SimpleNamespace(run_all=lambda **k: called.append(k))
    rec = CO.cbp_custody(volumes_root=_volumes(tmp_path, match=False), CBmod=fake)
    assert rec["status"] == "PENDING" and not called
    assert "cbp.closeout all --targets <PRIVATE_CACHE>/cbp_v1/run/closeout_targets.json" in rec["pending_command"]
    assert "no redundant cbp same-device copy" in rec["note"] and len(rec["gaps"]) == 4
    txt = (CO.CBP_CUSTODY_DIR / "STATUS.json").read_text()
    assert "Owner" not in txt and str(tmp_path) not in txt


def _open_assessment(tmp_path, monkeypatch, bind=True, complete=True):
    """A synthetic opening: EVALUATION_LOCK.json in the package, the lock reported on origin, and one assessment unit
    outer__s1__x in the live store whose record binds the lock's sha256 (bind) and is hash-complete (complete)."""
    CO.PKG.mkdir(parents=True, exist_ok=True)
    (CO.PKG / "EVALUATION_LOCK.json").write_text('{"schema": "lra-evaluation-lock-v1"}')
    monkeypatch.setattr(CO, "lra_lock_pushed", lambda: (True, "pushed (test)"))
    src = tmp_path / "live_store"
    u = src / "run" / "units" / "outer__s1__x"
    u.mkdir(parents=True, exist_ok=True)
    sha = hashlib.sha256((CO.PKG / "EVALUATION_LOCK.json").read_bytes()).hexdigest()
    (u / "record.json").write_text(json.dumps({"evaluation_lock": {"commit": "c" * 40,
                                                                   "sha256": sha if bind else "0" * 64}}))
    if complete:
        _complete(u)
    monkeypatch.setattr(CO, "SRC", src)
    return src


def test_assessment_opening_needs_the_pushed_lock_and_a_bound_assessment_unit(tmp_path, monkeypatch):
    ok, why, ev = CO.lra_assessment_opened()
    assert ok is False and "not verified on origin" in why and ev["bound_assessment_units"] == 0
    _open_assessment(tmp_path / "a", monkeypatch, bind=False)
    ok, why, _ = CO.lra_assessment_opened()
    assert ok is False and "has not been opened" in why                      # a unit bound to another lock
    _open_assessment(tmp_path / "b", monkeypatch, complete=False)
    assert CO.lra_assessment_opened()[0] is False                             # not hash-complete
    _open_assessment(tmp_path / "c", monkeypatch)
    ok, why, ev = CO.lra_assessment_opened()
    assert ok is True and ev["bound_assessment_units"] == 1 and len(ev["evaluation_lock_sha256"]) == 64
    (CO.PKG / "EVALUATION_LOCK.json").write_text('{"schema": "lra-evaluation-lock-v1", "changed": true}')
    assert CO.lra_assessment_opened()[0] is False                             # the bound lock is not this lock


def test_cbp_custody_stays_pending_before_this_studys_assessment_opening_even_with_the_drive(tmp_path, monkeypatch,
                                                                                               _isolate):
    """With the drive present, the cbp custody reaches osf's assessment (this study's assessment rows). Before this
    study's assessment opening it is recorded PENDING, never run, and osf's assessment is never opened: with no lock
    (e.g. ENGINEERING_BLOCKED_NOT_RUN: it will never exist) and also with the lock pushed but no bound assessment unit."""
    monkeypatch.setattr(CO, "source_code_identity", lambda: {"identical": True, "files": 1, "differing_from_cbp_tip": []})
    CO.PKG.mkdir(parents=True, exist_ok=True)
    (CO.PKG / "ENGINEERING_GATE_RESULT.json").write_text(json.dumps({"verdict": "ENGINEERING_BLOCKED"}))
    called = []
    from osf import assess as AS
    monkeypatch.setattr(AS, "open_assessment", lambda *a, **k: called.append("OPENED"))
    rec = CO.cbp_custody(volumes_root=_volumes(tmp_path), CBmod=types.SimpleNamespace(run_all=lambda **k: called.append(1)))
    assert rec["status"] == "PENDING" and not called and "EVALUATION_LOCK" in rec["reason"]
    assert "not yet opened" in rec["reason"] and rec["osf_assessment_opened"] is False
    assert rec["lra_assessment_state"]["study_label"] == "ENGINEERING_BLOCKED_NOT_RUN"
    assert rec["code_proof_of_no_early_read"]["status"] == "NOT_AVAILABLE"
    assert rec["pending_command"] == CO.PENDING["cbp_qpc_dpc_osf_smf_pending_custody_for_its_owner"]
    assert json.loads((CO.CBP_CUSTODY_DIR / "STATUS.json").read_text())["status"] == "PENDING"
    rec2 = CO.cbp_custody(volumes_root=_volumes(tmp_path / "x", match=False))      # drive absent: both reasons
    assert rec2["status"] == "PENDING" and "not mounted" in rec2["reason"] and "not yet opened" in rec2["reason"]
    _open_assessment(tmp_path, monkeypatch, bind=False)                           # lock pushed, nothing opened
    rec3 = CO.cbp_custody(volumes_root=_volumes(tmp_path / "y"), CBmod=types.SimpleNamespace(
        run_all=lambda **k: called.append(1)))
    assert rec3["status"] == "PENDING" and not called and "has not been opened" in rec3["reason"]
    assert rec3["lra_assessment_state"]["evaluation_lock_pushed"] is True


def _fake_cbp(tmp_path, write_closed=None):
    """A stand-in for cbp.closeout.run_all that writes through cbp / qpc / dpc closeout's own (rebound) receipt
    locations, as the pinned code does."""
    seen = {}

    def run_all(targets_file=None, volumes_root=None, out_pkg=None, **kw):
        seen.update(out_pkg=Path(out_pkg), pkg=CBC.PKG, qpc_dir=CBC.QPC_CUSTODY_DIR, closed=dict(CBC.CLOSED_RESULTS),
                    seal=CBC.osf_assessment_sealed_until_cbp_lock, targets=targets_file)
        CBC.write_public(CBC.QPC_CUSTODY_DIR / "STATUS.json", {"status": "RUN"})
        QC.write_public(CBC.QPC_CUSTODY_DIR / "dpc_custody" / "STATUS.json", {"status": "RUN", "x": float("inf")})
        CO.DC.write_public(CBC.QPC_CUSTODY_DIR / "predecessor_custody" / "STATUS.json", {"status": "RUN"})
        CBC.write_public(Path(out_pkg) / "BACKUP_VERIFICATION.json", {"status": "DRIVE_COPY_VERIFIED"})
        if write_closed is not None:
            CBC.write_public(write_closed / "BACKUP_VERIFICATION.json", {"status": "x"})
        return {"status": "DRIVE_COPY_VERIFIED", "files": 3, "uncached_readback_match": 3, "restore_all_pass": True,
                "required_restores": {"U teacher": "PASS"}, "components": {"qpc_custody": {"status": "RUN"}},
                "uncached_reread_of_drive_folders": {"all_pass": True}, "closed_results_unchanged": True}
    return types.SimpleNamespace(run_all=run_all), seen


def test_cbp_custody_with_drive_redirects_every_receipt_and_restores_bindings(tmp_path, monkeypatch, _isolate):
    monkeypatch.setattr(CO, "source_code_identity", lambda: {"identical": True, "files": 1, "differing_from_cbp_tip": []})
    _open_assessment(tmp_path, monkeypatch)
    tg = tmp_path / "cbp_targets.json"
    tg.write_text("{}")
    keys = ("PKG", "PROV", "QPC_CUSTODY_DIR", "CLOSED_RESULTS", "write_public", "osf_assessment_sealed_until_cbp_lock")
    orig = {k: getattr(CBC, k) for k in keys}
    orig_q, orig_d = QC.write_public, CO.DC.write_public
    fake, seen = _fake_cbp(tmp_path)
    rec = CO.cbp_custody(volumes_root=_volumes(tmp_path), CBmod=fake, cbp_targets=tg)
    out = CO.CBP_CUSTODY_DIR
    assert rec["status"] == "RUN" and rec["closed_results_unchanged"], rec
    assert seen["out_pkg"] == out and seen["pkg"] == out and seen["qpc_dir"] == out / "qpc_custody"
    assert seen["seal"] is CO.osf_assessment_sealed_until_lra_opening and "cbp_results" in seen["closed"]
    assert rec["lra_assessment_state"]["assessment_opened_by_this_study"] is True
    assert seen["targets"] == str(tg)
    for f in ("qpc_custody/STATUS.json", "qpc_custody/dpc_custody/STATUS.json",
              "qpc_custody/predecessor_custody/STATUS.json", "BACKUP_VERIFICATION.json", "STATUS.json"):
        assert (out / f).exists(), f
    assert "Infinity" not in (out / "qpc_custody" / "dpc_custody" / "STATUS.json").read_text()
    assert {k: getattr(CBC, k) for k in keys} == orig and QC.write_public is orig_q and CO.DC.write_public is orig_d
    assert "Owner" not in (out / "STATUS.json").read_text()


def test_cbp_custody_refuses_a_write_into_a_closed_tree(tmp_path, monkeypatch, _isolate):
    monkeypatch.setattr(CO, "source_code_identity", lambda: {"identical": True, "files": 1, "differing_from_cbp_tip": []})
    _open_assessment(tmp_path, monkeypatch)
    before = {k: CO.tree_state(v) for k, v in _isolate.items()}
    fake, _ = _fake_cbp(tmp_path, write_closed=_isolate["cbp_results"])
    orig_q = QC.write_public
    rec = CO.cbp_custody(volumes_root=_volumes(tmp_path), CBmod=fake)
    assert rec["runs"]["cbp_run_all"]["status"] == "FAILED" and "closed results" in rec["runs"]["cbp_run_all"]["reason"]
    assert rec["closed_results_unchanged"] and {k: CO.tree_state(v) for k, v in _isolate.items()} == before
    assert not (_isolate["cbp_results"] / "BACKUP_VERIFICATION.json").exists()
    assert QC.write_public is orig_q                                     # bindings restored after the failure


def test_cbp_custody_refuses_when_a_pinned_package_differs(tmp_path, monkeypatch):
    _open_assessment(tmp_path, monkeypatch)
    monkeypatch.setattr(CO, "source_code_identity", lambda: {"identical": False, "files": 9,
                                                             "differing_from_cbp_tip": ["cbp/closeout.py"]})
    called = []
    rec = CO.cbp_custody(volumes_root=_volumes(tmp_path), CBmod=types.SimpleNamespace(run_all=lambda **k: called.append(1)))
    assert rec["status"] == "REFUSED" and not called


def test_osf_assessment_stays_sealed_until_this_studys_assessment_opening(tmp_path, monkeypatch):
    from osf import assess as AS
    from osf import data as OD
    orig, orig_load = AS.open_assessment, OD.load
    calls = []
    monkeypatch.setattr(OD, "load", lambda verify=True, unseal=False: calls.append(unseal) or {"sealed": not unseal})
    stub = OD.load
    with CO.osf_assessment_sealed_until_lra_opening() as ok:              # no lock, no opening
        assert ok is False
        with pytest.raises(SystemExit, match="sealed by lra custody"):
            AS.open_assessment()
        with pytest.raises(SystemExit, match="sealed by lra custody"):
            OD.load(unseal=True)                                          # the root of every unsealing loader
        with pytest.raises(SystemExit, match="sealed by lra custody"):
            OD.load(True, True)
        assert OD.load(verify=True)["sealed"] is True and calls == [False]   # sealed loads pass through
    assert AS.open_assessment is orig and OD.load is stub
    _open_assessment(tmp_path, monkeypatch, bind=False)                   # lock pushed but not opened: still sealed
    with CO.osf_assessment_sealed_until_lra_opening() as ok:
        assert ok is False
    _open_assessment(tmp_path / "o", monkeypatch)
    monkeypatch.setattr(CBC, "cbp_lock_pushed", lambda: (False, "cbp lock missing"))
    with CO.osf_assessment_sealed_until_lra_opening() as ok:
        assert ok is False
    monkeypatch.setattr(CBC, "cbp_lock_pushed", lambda: (True, "pushed"))
    with CO.osf_assessment_sealed_until_lra_opening() as ok:
        assert ok is True and AS.open_assessment is orig and OD.load is stub
    monkeypatch.setattr(OD, "load", orig_load)


def test_study_label_follows_the_new_engineering_gate(tmp_path, monkeypatch):
    """ENGINEERING_BLOCKED -> ENGINEERING_BLOCKED_NOT_RUN; ENGINEERING_READY (verified) -> the locked inference label;
    no gate yet or no inference yet -> no label. The lcr MECHANISM_GATE_NOT_MET is never this study's label."""
    CO.PKG.mkdir(parents=True, exist_ok=True)
    gate = CO.PKG / "ENGINEERING_GATE_RESULT.json"
    assert CO.study_label()[0] is None                                    # the correctness stage has not run
    gate.write_text(json.dumps({"verdict": "ENGINEERING_BLOCKED"}))
    lab, why = CO.study_label()
    assert lab == "ENGINEERING_BLOCKED_NOT_RUN" and "NOT RUN" in why
    gate.write_text(json.dumps({"verdict": "ENGINEERING_READY"}))
    assert CO.study_label()[0] is None                                    # READY but not verified (not pushed / bound)
    monkeypatch.setattr(CO, "_engineering_ready", lambda: (True, "ENGINEERING_READY"))
    src = tmp_path / "store"
    assert CO.study_label(src=src) == (None, "no study label yet: the locked inference has not run "
                                             "(run/inference.json absent)")
    (src / "run").mkdir(parents=True)
    (src / "run" / "inference.json").write_text(json.dumps({"label": "EXPERIMENTAL_NO_ADVANTAGE [A=x; B=y; C=z; Q=w]"}))
    assert CO.study_label(src=src)[0] == "EXPERIMENTAL_NO_ADVANTAGE [A=x; B=y; C=z; Q=w]"

    def boom():
        raise SystemExit("no lock written")
    monkeypatch.setattr(CO, "_engineering_ready", boom)
    st = CO.engineering_gate_state()
    assert st["engineering_ready"] is False and "did not verify" in st["state"]
    for lab in (CO.study_label(src=src)[0], CO.lra_assessment_state(src)["study_label"]):
        assert lab != "MECHANISM_GATE_NOT_MET"


# ------------------------------------------------------------------ the full sequence
def test_run_all_with_drive_runs_in_order_and_rereads_new_folders(tmp_path, monkeypatch, _isolate):
    src = _store(tmp_path)
    vols = _volumes(tmp_path)
    disk = vols / "Owner Named Disk"
    order = []

    def fake_cbp_custody(dry_run, volumes_root, cbp_targets=None):
        order.append("cbp")
        for name in (f"private_cbp_v1_{DATE}", f"private_qpc_v1_{DATE}"):
            f = disk / name
            (f / "x").mkdir(parents=True)
            (f / "x" / "a").write_bytes(b"a")
            (f / "SHA256SUMS").write_text(f"{hashlib.sha256(b'a').hexdigest()}  x/a\n")
        (disk / "Owner Extra Folder").mkdir()                     # an unexpected new folder: name never published
        return {"status": "RUN"}
    monkeypatch.setattr(CO, "cbp_custody", fake_cbp_custody)
    _stub_restore(monkeypatch)
    out = tmp_path / "pkg"
    bv = CO.run_all(volumes_root=vols, src=src, cache=src.parent, out_pkg=out)
    assert order == ["cbp"] and bv["status"] == CO.STATUS_DRIVE
    rr = bv["uncached_reread_of_drive_folders"]
    for n in (f"private_cbp_v1_{DATE}", f"private_qpc_v1_{DATE}", f"private_lra_v1_{DATE}"):
        assert rr["created_by_this_closeout"][n]["pass"], n
    assert "<other new folder>" in rr["created_by_this_closeout"] and rr["all_pass"] is False
    assert rr["created_before_the_lra_copy"] == 3
    assert bv["closed_results_unchanged"] and bv["components"]["cbp_custody"]["status"] == "RUN"
    pub = (out / "BACKUP_VERIFICATION.json").read_text()
    assert "Owner" not in pub and str(tmp_path) not in pub


def test_run_all_without_drive_records_pending_and_makes_a_local_copy(tmp_path, monkeypatch, _isolate):
    src = _store(tmp_path)
    _stub_restore(monkeypatch)
    out = tmp_path / "pkg"
    bv = CO.run_all(volumes_root=_volumes(tmp_path, match=False), src=src, cache=src.parent, out_pkg=out)
    assert bv["status"] == CO.STATUS_LOCAL and bv["components"]["drive_mounted"] is False
    assert bv["components"]["cbp_custody"]["status"] == "PENDING"
    assert "cbp.closeout all" in bv["components"]["cbp_custody"]["pending_command"]
    assert (CO.CBP_CUSTODY_DIR / "STATUS.json").exists()
    assert (src.parent / f"lra_v1_local_copy_{DATE}" / "SHA256SUMS").exists()
    assert not list(src.parent.glob("cbp_v1_local_copy_*"))                # no redundant cbp same-device copy


# ------------------------------------------------------------------ an end-to-end D1 restore from a synthetic copy
def _d1_unit(live: Path, D, T, name="dec__s1__U_DIRECT-TASK_i2o2_D1", cid="U|DIRECT-TASK|i2o2|D1"):
    """A D1 unit in the lra format: a qpc token map (policy.json), the lra.decoder table pair (decoder.json) learned from
    the synthetic fitting labels, and release.npz from lra.decoder.release_arrays_d1."""
    from dpc import admit as DA
    from dpc import deploy as DDP
    from lra import decoder as DEC
    from qpc import kmeans as KM
    from qpc import release as RL
    msha = DA.sha(live / "admitted" / "rel__s1__U" / "model.pt")
    fsha = DDP.schema_sha256([str(x) for x in D["feature_names"]])
    fit = D["idx"]["OSF_DEFENSE_FIT"]
    pols = []
    for r, K, m in ((1, 2, 2), (2, 6, 2)):
        f = KM.fit_recipient(T[f"p{r}"][fit], T[f"d{r}"][fit], K, m)
        pols.append(RL.make_policy(r, f.partition if hasattr(f, "partition") else f[0]))
    pair = RL.make_pair(pols[0], pols[1], "DIRECT-TASK", 2, 2,
                        meta={"teacher_model_sha256": msha, "feature_names_sha256": fsha, "config": cid})
    decs = []
    for i, pol in ((1, pair.p1), (2, pair.p2)):
        tok, _, _ = RL.encode(pol, T[f"p{i}"][fit], T[f"d{i}"][fit])
        decs.append(DEC.decode_policy(pol, tok, T[f"p{i}"][fit], D["y"][CO.TASK_KEYS[i - 1]][fit], config=cid))
    u = live / "run" / "units" / name
    u.mkdir(parents=True)
    RL.save_policy(pair, u / "policy.json")
    DEC.save_decoder_pair(u / "decoder.json", cid, pair, decs[0], decs[1])
    np.savez(u / "release.npz", **DEC.release_arrays_d1(pair, decs[0], decs[1], D["row_id"], T["p1"], T["d1"], T["p2"],
                                                        T["d2"]))
    (u / "record.json").write_text(json.dumps({"seed": 1, "teacher": "U", "config": cid}))
    _complete(u)
    return name, pair, decs


def _synthetic_d1_world(tmp_path, monkeypatch):
    live = tmp_path / "PCRL_eval_cache_private" / "lra_v1"
    D, T = _synthetic_store(live)
    rng = np.random.default_rng(7)
    D["feature_names"] = np.asarray([f"f{j}" for j in range(83)])
    n = len(D["row_id"])
    # synthetic true labels, deliberately disagreeing with the teacher on some rows (a miscalibrated teacher)
    y1 = np.where(rng.random(n) < 0.8, T["d1"], 1 - T["d1"])
    y2 = np.where(rng.random(n) < 0.7, T["d2"], rng.integers(0, 6, n))
    D["y"] = {"income": y1.astype(np.int64), "occupation_group": y2.astype(np.int64)}
    D["sealed"] = True
    monkeypatch.setattr(CO, "fitting_labels", lambda D_, i: (np.asarray(D_["idx"]["OSF_DEFENSE_FIT"]),
                                                             np.asarray(D_["y"][CO.TASK_KEYS[i - 1]])[
                                                                 D_["idx"]["OSF_DEFENSE_FIT"]]))
    monkeypatch.setattr(QC, "DPC_UNITS", live / "run" / "units")   # stands in for the pinned dpc teacher unit
    monkeypatch.setattr(CO, "load_D_from_input", lambda p: (D if Path(p).read_bytes() == INPUT_BYTES else
                                                            (_ for _ in ()).throw(SystemExit("wrong input"))))
    name, pair, decs = _d1_unit(live, D, T)
    return live, D, T, name, pair, decs


def test_d1_restore_from_a_synthetic_copy_alone(tmp_path, monkeypatch):
    """The learned decoder re-certifies from the copy (hash, binding, bitwise re-solve, statistics recomputed from the
    copy's teacher and labels); the D1 release re-encodes bitwise; the learned vectors differ from the D0 means."""
    live, D, T, name, pair, decs = _synthetic_d1_world(tmp_path, monkeypatch)
    z = np.load(live / "run" / "units" / name / "release.npz")
    _, q0, _ = __import__("qpc.release", fromlist=["encode"]).encode(pair.p2, T["p2"], T["d2"])
    assert not np.array_equal(z["q2"], q0)                       # D1 released vectors are not the D0 means
    copy, _ = CO.copy_study(live, tmp_path / "copies" / "lra_v1_local_copy_t", {CO.DEP_REL: CO.INPUT})
    targets = {"seed": 1, "policies": {"P* (DIRECT-TASK; synthetic D1)": name}}
    checks, _ = CO.restore_all(copy, live, targets, 1, copy.parent / CO.DEP_REL)
    st = {k: v.get("status") for k, v in checks.items()}
    assert st["teacher U (seed 1)"] == "PASS" and st["P* (DIRECT-TASK; synthetic D1)"] == "PASS", checks
    c = checks["P* (DIRECT-TASK; synthetic D1)"]
    cert = c["decoder_recertified_from_copy"]
    assert cert["status"] == "PASS" and cert["re_solved_bitwise_from_stored_statistics"]
    assert all(cert[f"recipient_{i}"]["label_counts_equal"] and cert[f"recipient_{i}"]["counts_equal"] for i in (1, 2))
    assert all(v["bitwise"] for v in c["vs_copy_release"].values()) and all(c["decision_preserved_vs_restored_teacher"].values())
    assert c["deployment_from_copy"]["status"] == "NOT_RUN"
    req = CO.required_targets_status(st, checks)
    assert req["learned decoder"] == "PASS" and req["protected map"] == "PASS" and req["attacker"] == "PENDING"


def test_d1_restore_catches_tampered_release_decoder_and_labels(tmp_path, monkeypatch):
    live, D, T, name, pair, decs = _synthetic_d1_world(tmp_path, monkeypatch)
    targets = {"seed": 1, "policies": {"P*": name}}

    def fresh(tag):
        copy, _ = CO.copy_study(live, tmp_path / f"copies_{tag}" / "lra_v1_local_copy_t", {CO.DEP_REL: CO.INPUT})
        return copy

    # (1) a released D1 vector changed in the copy (one ulp)
    copy = fresh("q")
    z = dict(np.load(copy / "run" / "units" / name / "release.npz"))
    z["q2"] = z["q2"].copy()
    z["q2"][0, 0] = np.nextafter(z["q2"][0, 0], 2.0)
    np.savez(copy / "run" / "units" / name / "release.npz", **z)
    ch, _ = CO.restore_all(copy, live, targets, 1, copy.parent / CO.DEP_REL)
    assert ch["P*"]["status"] == "FAIL"
    # (2) a stored decoder vector changed CONSISTENTLY (u and q = smooth(u) moved together, every hash recomputed), so
    #     only the bitwise re-solve from the stored statistics can catch it
    #     The tampered file is written into the LIVE store with a consistent COMPLETE.json (a corrupted save), so the
    #     copy-integrity checks pass and the decoder re-certification must catch it.
    from lra import decoder as DEC
    from qpc.kmeans import smooth
    unit = live / "run" / "units" / name
    original = (unit / "decoder.json").read_bytes()
    body = json.loads(original)
    r2 = body["r2"]
    K = int(r2["K"])
    tc = np.asarray(r2["token_class"], dtype=np.int64)
    u = np.asarray(r2["u"], dtype=np.float64).reshape(-1, K)
    sup = [t for t, fb in enumerate(r2["fallback"]) if not fb][0]
    c, j, dlt = int(tc[sup]), (int(tc[sup]) + 1) % K, 1e-9
    if u[sup, j] >= dlt:
        u[sup, c], u[sup, j] = u[sup, c] + dlt, u[sup, j] - dlt
    else:
        u[sup, c], u[sup, j] = u[sup, c] - dlt, u[sup, j] + dlt
    q = smooth(u, tc, check=False)
    tab = DEC.DecoderTable(recipient=2, K=K, token_class=tc, n=np.asarray(r2["n"], dtype=np.int64),
                           y=np.asarray(r2["y"], dtype=np.float64).reshape(-1, K),
                           s=np.asarray(r2["s"], dtype=np.float64).reshape(-1, K), u=u, q=q,
                           fallback=np.asarray(r2["fallback"], dtype=bool), certs=r2["certs"],
                           policy_fingerprint=r2["policy_fingerprint"], config=r2.get("config"), meta=r2.get("meta", {}))
    r2.update({"u": u.tolist(), "q": q.tolist(), "content_hash": tab.content_hash()})
    body["decoder_sha256"] = DEC.decoder_hash(body)
    (unit / "decoder.json").write_text(json.dumps(body))
    _complete(unit)
    copy = fresh("dec")
    ch, _ = CO.restore_all(copy, live, targets, 1, copy.parent / CO.DEP_REL)
    assert ch["P*"]["status"] == "FAIL" and "registered solve" in ch["P*"]["decoder_recertified_from_copy"]["reason"]
    (unit / "decoder.json").write_bytes(original)
    _complete(unit)
    # (3) different fitting labels in the data the copy restores from: the recomputed label counts disagree
    copy = fresh("lab")
    D["y"]["occupation_group"] = (D["y"]["occupation_group"] + 1) % 6
    ch, _ = CO.restore_all(copy, live, targets, 1, copy.parent / CO.DEP_REL)
    cert = ch["P*"]["decoder_recertified_from_copy"]
    assert ch["P*"]["status"] == "FAIL" and cert["recipient_2"]["label_counts_equal"] is False
    assert cert["recipient_1"]["status"] == "PASS"


def test_d0_policy_targets_still_restore_through_the_pinned_qpc_path(tmp_path, monkeypatch):
    """A pol__ (D0) target is restored by qpc.closeout.restore_policy unchanged (re-encode + deployment from the copy)."""
    live, D, T, name, pair, decs = _synthetic_d1_world(tmp_path, monkeypatch)
    from qpc import release as RL
    d0 = "pol__s1__U_DIRECT-TASK_i2o2"
    u = live / "run" / "units" / d0
    u.mkdir(parents=True)
    p0 = RL.load_policy(live / "run" / "units" / name / "policy.json")
    p0.config["config"] = "U|DIRECT-TASK|i2o2"
    RL.save_policy(p0, u / "policy.json")
    np.savez(u / "release.npz", **RL.release_arrays(p0, D["row_id"], T["p1"], T["d1"], T["p2"], T["d2"]))
    (u / "record.json").write_text(json.dumps({"seed": 1, "teacher": "U", "config": "U|DIRECT-TASK|i2o2"}))
    _complete(u)
    copy, _ = CO.copy_study(live, tmp_path / "copies" / "lra_v1_local_copy_t", {CO.DEP_REL: CO.INPUT})
    ch, _ = CO.restore_all(copy, live, {"seed": 1, "policies": {"Q (synthetic D0)": d0, "P*": name}}, 1,
                           copy.parent / CO.DEP_REL)
    assert ch["Q (synthetic D0)"]["status"] == "PASS" and ch["P*"]["status"] == "PASS", ch
    assert ch["Q (synthetic D0)"]["deployment_from_copy"]["binding"] == "BOUND"


def test_role_targets_restore_from_the_copy_and_the_decoder_only_baseline_shares_the_tokens(tmp_path, monkeypatch):
    """Role targets restore from the copy: P* (a D1 unit, learned decoder re-certified) and its decoder-only baseline (a
    d0s__ same-map D0 unit through the pinned qpc path) carry bitwise identical tokens and decisions; their decoded
    vectors differ. A role with no release is NOT_APPLICABLE with its truthful status."""
    live, D, T, name, pair, decs = _synthetic_d1_world(tmp_path, monkeypatch)
    from qpc import release as RL
    d0 = "d0s__s1__U_DIRECT-TASK_i2o2_D1_D0SAME"
    u = live / "run" / "units" / d0
    u.mkdir(parents=True)
    p0 = RL.load_policy(live / "run" / "units" / name / "policy.json")
    p0.config["config"] = "U|DIRECT-TASK|i2o2|D1|D0SAME"
    RL.save_policy(p0, u / "policy.json")
    np.savez(u / "release.npz", **RL.release_arrays(p0, D["row_id"], T["p1"], T["d1"], T["p2"], T["d2"]))
    (u / "record.json").write_text(json.dumps({"seed": 1, "teacher": "U", "config": "U|DIRECT-TASK|i2o2|D1|D0SAME"}))
    _complete(u)
    roles = {"P*": {"status": "NOMINATED", "unit": name, "config": "U|DIRECT-TASK|i2o2|D1"},
             "decoder-only baseline": {"status": "FIXED", "unit": d0, "config": "U|DIRECT-TASK|i2o2|D1|D0SAME",
                                       "paired_with": "P*"},
             "sequential winner": {"status": "ABSENT", "reason": "synthetic world: no sequential arm"}}
    targets = {"seed": 1, "roles": roles}
    copy, _ = CO.copy_study(live, tmp_path / "copies" / "lra_v1_local_copy_t", {CO.DEP_REL: CO.INPUT})
    checks, _ = CO.restore_all(copy, live, targets, 1, copy.parent / CO.DEP_REL)
    st = {k: v.get("status") for k, v in checks.items()}
    lab_p, lab_b = CO.role_label("P*", roles["P*"]), CO.role_label("decoder-only baseline", roles["decoder-only baseline"])
    assert st[lab_p] == "PASS" and st[lab_b] == "PASS" and st[CO.SAME_MAP_CHECK] == "PASS", checks
    sm = checks[CO.SAME_MAP_CHECK]
    assert all(sm["identical"].values()) and sm["decoded_vectors_differ"]["q2"] is True
    assert checks[lab_b]["deployment_from_copy"]["binding"] == "BOUND"
    req = CO.required_targets_status(st, checks, None, roles, science_ran=True)
    assert req["protected map"] == "PASS" and req["decoder-only baseline"] == "PASS" and req["learned decoder"] == "PASS"
    assert req["sequential winner"] == "NOT_APPLICABLE (ABSENT: synthetic world: no sequential arm)"
    assert req["attacker"].startswith("FAIL")                    # the science ran: an attacker restore is required


def test_same_map_tokens_refuses_a_different_partition(tmp_path):
    units = tmp_path / "c" / "run" / "units"
    rows = np.arange(6, dtype=np.int64)
    base = {"row_id": rows, "tok1": np.array([0, 0, 1, 1, 2, 2]), "tok2": np.array([0, 1, 0, 1, 0, 1]),
            "hard1": np.array([0, 0, 1, 1, 1, 1]), "hard2": np.array([0, 1, 0, 1, 0, 1]),
            "q1": np.full((6, 2), 0.5), "q2": np.full((6, 6), 1 / 6)}
    for n, over in (("d0s__s1__a", {}), ("dec__s1__a", {"q1": np.full((6, 2), 0.4)}),
                    ("dec__s1__b", {"tok1": np.array([0, 1, 1, 1, 2, 2])})):
        (units / n).mkdir(parents=True)
        np.savez(units / n / "release.npz", **{**base, **over})
    ok = CO.same_map_tokens(tmp_path / "c", "d0s__s1__a", "dec__s1__a")
    assert ok["status"] == "PASS" and ok["decoded_vectors_differ"] == {"q1": True, "q2": False}
    bad = CO.same_map_tokens(tmp_path / "c", "d0s__s1__a", "dec__s1__b")
    assert bad["status"] == "FAIL" and bad["identical"]["tok1"] is False
    assert CO.same_map_tokens(tmp_path / "c", "d0s__s1__a", "dec__s1__missing")["status"] == "FAIL"
    assert CO.same_map_tokens(tmp_path / "c", "d0s__s1__a", None)["status"] == "FAIL"


def test_inventory_and_science_state_cover_the_new_namespaces(tmp_path):
    store = tmp_path / "s"
    for n in ("pol__s0__a", "dec__s0__a", "new__s0__U_K-LOCAL_i8o64_D1", "d0s__s0__a", "diag__s0__a", "cor__F1",
              "aud__dec__s0__a", "outer__s0__x"):
        (store / "run" / "units" / n).mkdir(parents=True)
    (store / "run" / "units" / "new__s0__U_K-LOCAL_i8o64_D1" / "trace.json").write_text("{}")
    inv = CO.unit_inventory(store)
    assert {k: inv[k] for k in ("pol", "dec", "new", "d0s", "diag", "cor", "aud", "outer")} == {
        "pol": 1, "dec": 1, "new": 1, "d0s": 1, "diag": 1, "cor": 1, "aud": 1, "outer": 1}
    assert inv["units_with_trace.json"] == 1
    assert CO.science_state(store)["science_ran"] is False                    # no hash-complete D1 unit yet
    _complete(store / "run" / "units" / "new__s0__U_K-LOCAL_i8o64_D1")
    assert CO.science_state(store) == {"adult_d1_fixed_map_units": 0, "adult_new_fit_units": 1, "science_ran": True}
    ri = CO.restore_index("<PRIVATE_CACHE>", tmp_path / "lra_v1_local_copy_x", {}, True)
    lay = json.dumps(ri["layout"])
    assert all(x in lay for x in ("d0s__", "diag__", "cor__", "trace.json", "outer__", "aud__"))
    assert "fix__" not in lay


def test_the_copy_input_loader_refuses_a_missing_or_unpinned_file(tmp_path):
    with pytest.raises(SystemExit, match="no bundled input"):
        CO.load_D_from_input(tmp_path / "missing.npz")
    other = tmp_path / "other.npz"
    other.write_bytes(b"not the pinned input")
    with pytest.raises(SystemExit, match="pinned hash"):
        CO.load_D_from_input(other)


# ------------------------------------------------------------------ incremental refresh of the copy
def test_refresh_adds_new_files_and_grown_ledgers_and_deletes_nothing(tmp_path, monkeypatch):
    src = _store(tmp_path)
    (src / "run" / "SEMA_LOG.jsonl").write_text("a\n")
    (src / "run" / "units" / "u" / "frozen.bin").write_bytes(b"frozen")
    out = tmp_path / "pkg"
    _stub_restore(monkeypatch)
    CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=out)
    root = src.parent / f"lra_v1_local_copy_{DATE}"
    old_sums = (root / "SHA256SUMS").read_text()
    (src / "run" / "SEMA_LOG.jsonl").write_text("a\nb\n")                     # append-only ledger grew
    (src / "run" / "units" / "v").mkdir()
    (src / "run" / "units" / "v" / "new.bin").write_bytes(b"new")             # a unit written after the copy
    (src / "run" / "units" / "u" / "frozen.bin").write_bytes(b"CHANGED")      # a non-append change: never overwritten
    (root / "lra_v1" / "only_in_copy.txt").write_text("kept")
    s = CO.refresh(src=src, cache=src.parent, out_pkg=out, protect=["lra_v1/run/units/u/"])
    assert s["new"] == 1 and s["appended"] == 1 and s["refused_non_append_change"] == ["lra_v1/run/units/u/frozen.bin"]
    assert s["restore_evidence_stale_for"] == ["lra_v1/run/units/u/frozen.bin"] and s["pass"]
    assert (root / "lra_v1" / "run" / "SEMA_LOG.jsonl").read_text() == "a\nb\n"
    assert (root / "lra_v1" / "run" / "units" / "u" / "frozen.bin").read_bytes() == b"frozen"
    assert (root / "lra_v1" / "only_in_copy.txt").exists() and (root / s["previous_SHA256SUMS_kept_as"]).read_text() == old_sums
    assert CO.verify_sums(root)["pass"] and s["entries"] == len(old_sums.splitlines()) + 1
    assert s["kept_only_in_copy"] == 0 and s["bundled_dependencies_kept"] == 1     # the bundled input is not "lost"
    bv = json.loads((out / "BACKUP_VERIFICATION.json").read_text())
    assert bv["refreshes"][-1]["appended"] == 1 and bv["files"] == s["entries"] and "STALE" in bv["restore_evidence_note"]
    assert str(tmp_path) not in (out / "BACKUP_VERIFICATION.json").read_text()


def test_refresh_reports_store_files_missing_from_the_live_store_but_not_the_bundled_input(tmp_path, monkeypatch):
    """A store file that disappeared from the live store after the copy is counted (and kept in the copy); the bundled
    pinned input, which never lives in the store, is reported separately and never as a missing store file."""
    src = _store(tmp_path)
    _stub_restore(monkeypatch)
    CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=tmp_path / "pkg")
    root = src.parent / f"lra_v1_local_copy_{DATE}"
    s0 = CO.refresh(src=src, cache=src.parent, out_pkg=tmp_path / "pkg", dry_run=True)
    assert s0["kept_only_in_copy"] == 0 and s0["kept_only_in_copy_files"] == [] and s0["bundled_dependencies_kept"] == 1
    (src / "START.txt").unlink()                                              # gone from the live store
    s1 = CO.refresh(src=src, cache=src.parent, out_pkg=tmp_path / "pkg")
    assert s1["kept_only_in_copy"] == 1 and s1["kept_only_in_copy_files"] == ["lra_v1/START.txt"]
    assert (root / "lra_v1" / "START.txt").exists() and (root / CO.DEP_REL).exists() and s1["pass"]


def test_refresh_never_picks_another_studys_copy_and_dry_run_writes_nothing(tmp_path, monkeypatch):
    src = _store(tmp_path)
    _stub_restore(monkeypatch)
    other = src.parent / "cbp_v1_local_copy_20991231"                          # another study's copy: never refreshed
    other.mkdir()
    (other / "SHA256SUMS").write_text("")
    CO.backup(src=src, cache=src.parent, volumes_root=_volumes(tmp_path, match=False), out_pkg=tmp_path / "pkg")
    root = src.parent / f"lra_v1_local_copy_{DATE}"
    (src / "run" / "units" / "u" / "late.bin").write_bytes(b"late")
    before = sorted(str(p) for p in root.rglob("*"))
    bv0 = (tmp_path / "pkg" / "BACKUP_VERIFICATION.json").read_text()
    s = CO.refresh(src=src, cache=src.parent, out_pkg=tmp_path / "pkg", dry_run=True)
    assert s["new"] == 1 and s["copy"] == f"<PRIVATE_CACHE>/lra_v1_local_copy_{DATE}"
    assert sorted(str(p) for p in root.rglob("*")) == before
    assert (tmp_path / "pkg" / "BACKUP_VERIFICATION.json").read_text() == bv0
    assert sorted(p.name for p in other.iterdir()) == ["SHA256SUMS"]
    with pytest.raises(SystemExit, match="no existing copy"):
        CO.refresh(src=src, cache=tmp_path / "empty", out_pkg=tmp_path / "pkg")
